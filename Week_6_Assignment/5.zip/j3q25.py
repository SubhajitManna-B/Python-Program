class NoArgumentConstructorExample:
    def __init__(self):
        print("This is a 0-argument constructor.")

def main():
    # Create an instance of NoArgumentConstructorExample
    example_object = NoArgumentConstructorExample()
    print("Object created successfully!")

if __name__ == "__main__":
    main()

