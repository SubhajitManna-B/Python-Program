items = ['Python', 'Numpy', 'Pandas', 'Django', 'Flask']

for item in items:
    print(item)
